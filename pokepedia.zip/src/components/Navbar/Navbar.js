import React from 'react';
import './style.css';

function Navbar() {
    return (
        <div className="Navbar">
            Pokepedia
        </div>
    );
}

export default Navbar;
