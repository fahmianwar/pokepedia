import React from 'react';
import typeColors from '../../helpers/typeColors'

function Card({ pokemon }) {
    return (
        <div className="col-md-3">
            <div className="card mb-3 shadow-sm">
                <img src={pokemon.sprites.front_default} alt="{pokemon.name}"/>
                    <div className="card-body">
                        <p className="card-text text-center"><strong>{pokemon.name.toUpperCase()}</strong></p>
                        {
                    pokemon.types.map(type => {
                        return (
                            <span class="badge badge-secondary" style={{ backgroundColor: typeColors[type.type.name] }}>{type.type.name}</span>
                            )
                        })
                    }
                    <br />
                        <i class="fa fa-text-height" aria-hidden="true"></i> {pokemon.height}<br />
                            <i class="fa fa-balance-scale" aria-hidden="true"></i> {pokemon.weight}<br />
                            <i class="fa fa-balance-skills" aria-hidden="true"></i> {pokemon.abilities[0].ability.name}

                        <div className="d-flex justify-content-between align-items-center">
                            <div className="btn-group">
                            <button type="button" className="btn btn-primary" onclick="save({pokemon.name})" data-toggle="modal" data-target="#exampleModal" data-whatever={pokemon.name}>Catch {pokemon.name}</button>
                            </div>

                            <small className="text-muted">9 mins</small>
                        </div>
                    </div>
            </div>
        </div>  
    );
}

export default Card;
